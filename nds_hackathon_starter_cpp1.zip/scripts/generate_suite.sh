#!/usr/bin/env bash
set -euo pipefail

generator="${1:-./nds_generate}"
output_dir="${2:-generated_data}"
mkdir -p "$output_dir"

"$generator" --preset aligned --submits 4 --iocbs 32 --iovs 1 --seed 101 -o "$output_dir/01_aligned.json" >/dev/null
"$generator" --preset low-unaligned --submits 8 --iocbs 64 --seed 102 -o "$output_dir/02_low_unaligned.json" >/dev/null
"$generator" --preset high-unaligned --submits 8 --iocbs 64 --seed 103 -o "$output_dir/03_high_unaligned.json" >/dev/null
"$generator" --preset fragmented --seed 104 -o "$output_dir/04_fragmented.json" >/dev/null
"$generator" --preset balanced --submits 12 --iocbs 64 --size-profile mixed --seed 105 -o "$output_dir/05_mixed_size.json" >/dev/null
"$generator" --preset reuse-hot --seed 106 -o "$output_dir/06_reuse_hot.json" >/dev/null
"$generator" --preset no-reuse --seed 107 -o "$output_dir/07_no_reuse.json" >/dev/null
"$generator" --preset ttl-expiry --seed 108 -o "$output_dir/08_ttl_expiry.json" >/dev/null
"$generator" --preset buffer-pressure --seed 109 -o "$output_dir/09_buffer_pressure.json" >/dev/null
"$generator" --preset concurrency-pressure --seed 110 -o "$output_dir/10_concurrency_pressure.json" >/dev/null

echo "generated 10 traces in $output_dir"
