# NDS多路径IO调度赛题 C++17 参考框架

这是 Python 参考框架的 C++17 对应版本，使用相同的输入、调度决策、PROMOTE和结果格式。

## 包含内容

- 内置轻量JSON解析和序列化，不依赖第三方JSON库；
- JSON Trace及固定实例参数校验；
- DIRECT、AGGREGATE、FALLBACK、PROMOTE_SSD、PROMOTE_HBM；
- 混合size和动态共享带宽离散事件循环；
- HBM/DDR容量、H2D/D2H/D2D并发、全局iocb容量模型；
- Mooncake容量、TTL、LRU驱逐和命中H2D；
- 512B对齐、有效范围覆盖、传输依赖、完成事件和指标校验；
- 不读取未来Trace的在线贪心baseline；
- 三组小规模Trace和C++测试程序。

## 目录

```text
nds_hackathon_starter_cpp/
├── include/nds/
│   ├── json.hpp
│   └── framework.hpp
├── src/
│   ├── json.cpp
│   ├── framework.cpp
│   ├── generate_main.cpp
│   ├── baseline_main.cpp
│   └── validate_main.cpp
├── tests/framework_test.cpp
├── data/
├── generated_data/             # 已生成的10组梯度用例
├── scripts/generate_suite.sh
├── CMakeLists.txt
└── Makefile
```

## 编译与运行

使用Make：

```bash
make -j
./nds_baseline data/small_mixed.json result.json
./nds_validate data/small_mixed.json result.json
make test
```

## 可配置测试数据生成器

`nds_generate`直接生成可被baseline和校验器读取的完整Trace：

```bash
./nds_generate \
  --output custom.json \
  --submits 20 \
  --iocbs-min 64 \
  --iocbs-max 256 \
  --iovs-min 1 \
  --iovs-max 8 \
  --reuse-rate 0.35 \
  --unaligned-rate 0.60 \
  --adjacent-rate 0.70 \
  --hbm-fragment-rate 0.80 \
  --size-profile mixed \
  --hotset-size 64 \
  --arrival-gap-us 100 \
  --seed 20260904

./nds_baseline custom.json custom.solution.json
./nds_validate custom.json custom.solution.json
```

支持的核心参数：

| 参数 | 含义 |
|---|---|
| `--submits` | Trace中的io_submit数量 |
| `--iocbs` | 每个submit固定iocb数 |
| `--iocbs-min/max` | 每个submit随机iocb数范围，最大1024 |
| `--iovs` | 每个iocb固定iov数 |
| `--iovs-min/max` | 每个iocb随机iov数范围 |
| `--reuse-rate` | 已有SSD对象被再次请求的概率 |
| `--unaligned-rate` | 新对象不满足512B对齐的概率 |
| `--adjacent-rate` | 新对象与上一个SSD区间相邻的概率 |
| `--hbm-fragment-rate` | 相邻iov之间出现HBM地址空洞的概率 |
| `--hotset-size` | 复用对象从最近多少个唯一对象中选择 |
| `--size-profile` | `tiny`、`mixed`或`large` |
| `--sizes` | 自定义iov长度列表，例如`512,584,4096,65536` |
| `--arrival-gap-us` | submit基础到达间隔 |
| `--arrival-jitter-us` | 到达间隔的随机增量 |
| `--cards` | 生成的NPU卡数量 |
| `--seed` | 随机种子，相同参数和种子产生相同Trace |

也可以修改资源压力：

```bash
./nds_generate --preset buffer-pressure \
  --hbm-capacity-mb 1 \
  --ddr-capacity-mb 4 \
  --iocb-capacity 128 \
  --h2d-concurrency 16 \
  --d2d-concurrency 16 \
  -o pressure.json
```

每个生成文件包含`generator_metadata`，记录请求参数和实际生成出的复用率、非对齐率、相邻率、HBM碎片率、唯一对象数和总iov数。

复用对象按`(device_id, ssd_offset, length)`识别。再次请求相同对象时SSD范围不变，但会生成新的HBM目标地址，模拟相同KV对象在后续推理请求中被加载到新的目标位置。

### 预置测试集

生成10组梯度用例：

```bash
bash scripts/generate_suite.sh ./nds_generate generated_data
```

预置负载包括：全对齐、低非对齐、高非对齐、高碎片、混合size、高复用、无复用、TTL过期、缓冲区压力和全局iocb并发压力。

压缩包内的`generated_data/`已经包含这10组用例，不运行生成脚本也可以直接使用。

使用CMake：

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
ctest --test-dir build --output-on-failure
./build/nds_baseline data/small_mixed.json result.json
./build/nds_validate data/small_mixed.json result.json
```

关闭baseline的PROMOTE策略：

```bash
./nds_baseline data/small_repeated.json result.json --no-promote
```

## 参赛策略接口

继承`nds::SchedulerPolicy`并实现：

```cpp
Json on_submit(const Submit& submit, const Json& runtime_state) override;

std::optional<Json> on_iocb_complete(
    const Iocb& iocb,
    const Json& runtime_state) override;
```

事件循环只把当前未命中的submit、历史状态和当前运行状态交给策略，不暴露未来Trace。

`on_iocb_complete()`用于自主决定是否启动后台PROMOTE。结果中的`promotion_decisions`是供独立校验器重放的审计记录，不是上层下发给调度器的PROMOTE任务。

## Baseline策略

1. SSD地址、HBM地址和长度均满足512B对齐时选择DIRECT；
2. 非对齐且读放大不超过1.5倍、分块可装入HBM聚合池时选择AGGREGATE；
3. 其他请求选择FALLBACK；
4. 同一缓存键第二次未命中完成后选择PROMOTE_HBM；
5. 不做跨iocb聚合和局部搜索。

Baseline的作用是产生合法参考解，不代表高质量竞赛算法。

## 确定性与当前边界

- 同一时刻就绪项按priority降序、transfer_id升序启动；
- SSD不设置独立QD或`nr_requests`硬限制，它们的影响视为已包含在性能桶中；
- DIRECT和SSD→DDR共享同一个NVMe带宽活动集合；
- 完成时间和成本由模拟器计算，参赛策略不能直接填写；
- C++版本内部使用`long double`推进事件，输出时统一向上取整到整数微秒；同一二进制重放具有确定性；
- 当前MVP仅支持READV，默认从空的运行状态开始；
- `runtime_limits`由外层比赛沙箱执行，本进程只负责解析；
- 正式发布前应冻结所有性能桶边界和COST常量。
